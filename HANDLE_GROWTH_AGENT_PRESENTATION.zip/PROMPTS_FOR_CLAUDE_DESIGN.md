# 📝 PROMPTS FOR CLAUDE DESIGN

## How to Use This File

Copy-paste these prompts into Claude Design to generate professional slides.

Each prompt is designed to create one slide or a series of related slides.

---

## PROMPT 1: Title Slide

```
Create a professional title slide for a business presentation with this information:

Title: "Handle Growth Agent"
Subtitle: "A System That Scales Sales Without You"

Include:
- Bold, modern typography
- Blue color scheme (#0066cc as primary)
- Clean minimalist design
- One visual element (icon, shape, or abstract illustration)
- Professional but approachable tone

The slide should convey: innovation, growth, AI-powered, systematic
```

---

## PROMPT 2: Problem Statement

```
Create a slide about the problem with this structure:

Headline: "The Problem: Stuck at 75 Brokers"

Key points:
- Handle has product-market fit ✅
- Handle has traction ✅
- Handle has funding ✅
- But: Sales don't scale without Poncho ❌
- Every insight disappears ❌
- No systematic playbook ❌

Include:
- Icon or visual for "bottleneck"
- Red/warning color for problems
- Blue color for what works
- Data visualization showing the 75 broker plateau
```

---

## PROMPT 3: Solution Overview

```
Create a slide explaining the Growth Agent solution:

Title: "The Solution: Growth Agent"
Subtitle: "An AI System That Learns"

Show 5 boxes/circles in a process flow:
1. Lead Generation (Filters)
2. Outreach (Personalizes)
3. Intelligence (Captures)
4. Learning (Identifies patterns)
5. Predictions (Forecasts)

Include:
- Icons for each component
- Blue color scheme
- Arrows showing flow
- One sentence description per component
- Overall result at bottom: "3 weeks later: Playbook your team can execute"
```

---

## PROMPT 4: How It Works - Lead Generation

```
Create an infographic slide for Lead Generation component:

Title: "Component 1: Lead Generation & Scoring"

Show the process:
INPUT: "50 insurance brokers in Mexico"
↓
PROCESS: Scores by receptiveness, budget, signals
↓
OUTPUT: Ranked list (show sample data)
  1. Inter.mx - 95%
  2. Genomma Lab - 87%
  3. De Acero - 82%

Include:
- Simple icons
- Color gradient (red 0% → green 100%)
- Show confidence scores visually
- Clean layout
```

---

## PROMPT 5: Timeline Visualization

```
Create a 3-week timeline visualization:

Week 1: Lead Generation
  └─ 50 brokers scored
  └─ Top 30 identified

Week 2: Outreach & Intelligence
  └─ 30 emails sent
  └─ Conversations analyzed

Week 3: Playbook Learning
  └─ 7-10 patterns identified
  └─ PLAYBOOK v1.0 ready

Visual style:
- Vertical or horizontal timeline
- Progress indicators
- Icons for each milestone
- Color progression (lighter to darker blue)
- Show deliverables clearly
```

---

## PROMPT 6: Key Metrics Dashboard

```
Create a metrics/results slide with key numbers:

Metrics to display:
- 50 brokers scored
- 30 conversations analyzed
- 7-10 patterns identified
- 95% confidence on primary pain point
- 40%+ expected response rate
- 3 weeks timeline
- $7k investment

Display as:
- Large numbers with small labels below
- Organized in grid (2x4 or 3x3)
- Use blue color scheme
- Add icons where relevant
- Professional dashboard style
```

---

## PROMPT 7: Cost Breakdown

```
Create a cost breakdown slide:

Budget Items:
- Apollo.io (lead data): $49/month
- Claude API (AI): ~$20/month
- Infrastructure (Gmail, Supabase, Slack): $14/month
- Professional services (3 weeks): $7,000

Show as:
- Pie chart or stacked bar chart
- Breakdown showing monthly + one-time costs
- ROI calculation: Payback in <1 month
- Comparison to alternative (hiring 3 AEs = $450k)

Title: "Phase 1 Budget: $7k Investment, 400% ROI"
```

---

## PROMPT 8: The Ask

```
Create a clear "Call to Action" slide:

What I'm asking for:
1. Approval for Phase 1 (3 weeks, $7k)
2. Access to last 10-15 conversations
3. Weekly 30-min sync on Mondays

What you get:
- Week 1: Ranked broker list
- Week 2: Analyzed conversations
- Week 3: PLAYBOOK v1.0

Format:
- Left side: What I need (3 items)
- Right side: What you get (3 weeks of deliverables)
- Center or bottom: "Are you ready? Yes / No / Maybe"
- Color: Professional blue, clear sections
```

---

## PROMPT 9: Full Presentation Flow

```
Create a slide deck presentation with these 10 sections:

1. Title: Handle Growth Agent
2. Problem: Stuck at 75 brokers
3. Solution: Growth Agent overview
4. How it Works: 5 components
5. Results: 3-week deliverables
6. Timeline: Week-by-week breakdown
7. Technical: APIs and tech stack (high-level)
8. Cost: Budget and ROI
9. The Ask: What I need
10. Next Steps: Decision timeline

Requirements:
- Consistent blue (#0066cc) color scheme
- Modern, minimal design
- Professional tone
- Clear hierarchy
- Icons and visuals where appropriate
- Slide numbers
- Navigation possible
```

---

## PROMPT 10: Interactive Demo Visualization

```
Create an interactive visualization showing:

Title: "Growth Agent in Action"

Demo flow showing:
1. Apollo.io finds 50 brokers (screenshot-style)
2. Claude AI scores them (animation-style)
3. Gmail sends personalized emails (flow)
4. Responses come in (counter incrementing)
5. Claude analyzes conversations (data processing visual)
6. Playbook emerges (knowledge graph)

Include:
- Real example data (Inter.mx, Genomma Lab, etc)
- Live counters/metrics updating
- Color progression
- Show timing (2 sec, 30 sec, automated, etc)
- Interactive elements if possible
```

---

## PROMPT 11: Comparative Analysis (Growth Agent vs Hiring)

```
Create a comparison slide:

Left column: Traditional Hiring (3 AEs)
- Cost: $450k
- Timeline: 6-12 months
- Risk: High (execution dependent)
- Productivity: 60-70% at month 6

Right column: Growth Agent
- Cost: $7k
- Timeline: 3 weeks
- Risk: Low (proven system)
- Productivity: Day 1 (playbook ready)

Visual:
- Side-by-side comparison
- Use icons/colors to show difference
- Highlight Growth Agent advantages
- Show ROI comparison clearly
```

---

## PROMPT 12: Next Steps / Call to Action

```
Create a final slide with next steps:

This Week:
[ ] Confirm approval for Phase 1
[ ] Schedule data access sync
[ ] Set up Monday weekly call

Monday (Start):
[ ] Set up dev environment
[ ] Integrate APIs
[ ] Begin lead scoring

By Friday Week 1:
[ ] 50 brokers scored
[ ] Top 30 identified
[ ] Review with Poncho

Format:
- Checklist style
- Timeline on left
- Actionable items on right
- Color: Professional blue
- Call to action at bottom: "Ready to start? Let's go."
```

---

## How to Use These

1. **Copy a prompt above**
2. **Go to Claude Design**
3. **Paste the prompt**
4. **Claude Design generates the slide**
5. **Edit/refine as needed**
6. **Combine all slides into presentation**

---

## Pro Tips

- Start with PROMPT 1 (Title) + PROMPT 9 (Full deck)
- Use PROMPT 4, 5, 6 for detailed component slides
- Use PROMPT 7 for financial credibility
- Use PROMPT 8 or 12 for closing
- Use PROMPT 10 if you want interactive demo

---

**Ready to generate your presentation. Pick a prompt and go.**
